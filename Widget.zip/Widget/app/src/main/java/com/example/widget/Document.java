package com.example.widget;

public class Document {
    private String name;
    private int imageId;
    private String time;

    public Document(String name, int imageId, String time) {
        this.name = name;
        this.imageId = imageId;
        this.time = time;
    }

    public int getImageId() {
        return imageId;
    }

    public String getName() {
        return name;
    }

    public String getTime() {
        return time;
    }
}

package com.example.widget;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import java.util.ArrayList;
import java.util.List;

public class GridWidgetService extends RemoteViewsService {
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new GridRemoteViewsFactory(this.getApplicationContext(), intent);
    }
}

class GridRemoteViewsFactory implements RemoteViewsService.RemoteViewsFactory {
    private static final int count = 10;
    private List<Document> mDataList = new ArrayList<Document>();
    private Context context;
    private int appWidgetId;

    public GridRemoteViewsFactory(Context context, Intent intent) {
        Log.d("GridWidgetService", "构造: GridWidgetService");
        this.context = context;
        appWidgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
    }

    public void onCreate() {
        Log.d("GridWidgetService", "onCreate: GridWidgetService");
        for (int i = 0; i < 5; i++) {
            Document item = new Document("item"+i, R.drawable.ic_launcher_foreground, "今天");
            mDataList.add(item);
        }
    }

    @Override
    public void onDataSetChanged() {

    }

    @Override
    public void onDestroy() {

    }

    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public RemoteViews getViewAt(int position) {
        // Construct a remote views item based on the app widget item XML file,
        // and set the text based on the position.
        RemoteViews rv = new RemoteViews(context.getPackageName(), R.layout.documents_item);
        rv.setTextViewText(R.id.document_name, mDataList.get(position).getName());
        rv.setTextViewText(R.id.document_time, mDataList.get(position).getTime());
        rv.setImageViewResource(R.id.document_image, mDataList.get(position).getImageId());

        return rv;
    }

    @Override
    public RemoteViews getLoadingView() {
        return null;
    }

    @Override
    public int getViewTypeCount() {
        return 0;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

}
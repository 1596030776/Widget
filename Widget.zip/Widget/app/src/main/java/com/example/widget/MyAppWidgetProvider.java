package com.example.widget;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.RemoteViews;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Date;

/**
 * Implementation of App Widget functionality.
 */
public class MyAppWidgetProvider extends AppWidgetProvider {
    //定义一个action，这个action要在AndroidMainfest中去定义，不然识别不到，名字是自定义的
    private static final String CLICK_ACTION = "com.barry.widgetapp.plus.CLICK";
    private static final String REFRESH_ACTION = "com.barry.widgetapp.plus.FRESH";

    private TextView tv;
    private static int num = 0;

    //onReceive不存在widget生命周期中，它是用来接收广播，通知全局的
    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
        //当我们点击桌面上的widget按钮（这个按钮我们在onUpdate中已经为它设置了监听），widget就会发送广播
        //这个广播我们也在onUpdate中为它设置好了意图，设置了action，在这里我们接收到对应的action并做相应处理
        if (intent.getAction().equals(CLICK_ACTION)) {

            Intent activityIntent = new Intent(context, MainActivity.class);
            activityIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(activityIntent);

        } else if (intent.getAction().equals(REFRESH_ACTION)) {

        }
    }

    //当widget第一次添加到桌面的时候回调，可添加多次widget，但该方法只回调一次
    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        Toast.makeText(context,"创建成功",Toast.LENGTH_SHORT).show();
    }

    //当widget被初次添加或大小被改变时回调
    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager appWidgetManager, int appWidgetId, Bundle newOptions) {
        super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions);
        Log.d("MyAppWidgetProvider", "onAppWidgetOptionsChanged: resize widget");
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        //因为可能有多个widget，所以要对它们全部更新
        for (int appWidgetId : appWidgetIds) {
            //创建一个远程view，绑定我们要操控的widget布局文件
            @SuppressLint("RemoteViewLayout")
            RemoteViews remoteViews = new RemoteViews(context.getPackageName(),R.layout.my_app_widget_provider);

            Intent intentClick = new Intent(context,MyAppWidgetProvider.class);
            Intent intentRefresh = new Intent(context, MyAppWidgetProvider.class);
            //这个必须要设置，不然点击效果会无效
            intentRefresh.setAction(REFRESH_ACTION);
            intentClick.setAction(CLICK_ACTION);
            //PendingIntent表示的是一种即将发生的意图，区别于Intent它不是立即会发生的
            PendingIntent pendingIntentClick = PendingIntent.getBroadcast(context,0,intentClick,PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            PendingIntent pendingIntentRefresh = PendingIntent.getBroadcast(context,0,intentRefresh,PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            //为布局文件中的按钮设置点击监听
            remoteViews.setOnClickPendingIntent(R.id.btn,pendingIntentRefresh);
            //为整个widget设置点击监听
            remoteViews.setOnClickPendingIntent(R.id.my_app_widget_provider, pendingIntentClick);

            //用于启动GridWidgetService的intent
            Intent intentGrid = new Intent(context, GridWidgetService.class);
            //将widget id作为参数传递
            intentGrid.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
            intentGrid.setData(Uri.parse(intentGrid.toUri(Intent.URI_INTENT_SCHEME)));
            //设置远程adapter，远程adapter通过GridWidgetService请求RemoteViews
            remoteViews.setRemoteAdapter(R.id.grid_view, intentGrid);
            remoteViews.setEmptyView(R.id.grid_view, R.id.empty_view);

            //告诉AppWidgetManager对当前应用程序小部件执行更新
            appWidgetManager.updateAppWidget(appWidgetId,remoteViews);
        }
        super.onUpdate(context, appWidgetManager, appWidgetIds);
    }

    //当 widget 被删除时回调
    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {
        super.onDeleted(context, appWidgetIds);
    }

    //当最后一个widget实例被删除时回调.
    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
    }
}